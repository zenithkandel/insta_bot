__DEV__=0;/*FB_PKG_DELIM*/
self.__swData=JSON.parse(/*BTDS*/"{\"dynamic_data\":{\"dynamic_modules\":{\"cr:3725\":{\"__rc\":[\"clearTimeoutSW\",null]},\"cr:4344\":{\"__rc\":[\"setTimeoutSW\",null]},\"cr:6640\":{\"__rc\":[null,null]},\"ServiceWorkerSiteData\":{\"revision\":1055532492,\"logErrors\":false,\"fbRevHeader\":\"X-FB-Rev\",\"fbDynSpinExpHeader\":\"x-fb-dyn-spin-exp\",\"disableSWHeader\":\"x-service-worker-disable\",\"siteTypeHeader\":\"x-fb-site-type\",\"siteType\":null,\"nonceHeader\":\"x-fb-nonce\",\"liteVersionHeader\":\"x-fb-lite-version\",\"currentUser\":\"0\",\"expireTime\":1795309200000},\"ServiceWorkerQuickExperimentData\":{\"type\":\"off\",\"pinning_ttl\":0}},\"hsdp\":{}}}");/*FB_PKG_DELIM*/

      if (self.trustedTypes && self.trustedTypes.createPolicy) {
        const escapeScriptURLPolicy = self.trustedTypes.createPolicy("workerPolicy", {
          createScriptURL: url => url
        });
        importScripts(escapeScriptURLPolicy.createScriptURL(/*BTDS*/"https:\/\/static.cdninstagram.com\/rsrc.php\/v4\/yC\/r\/378h91_48Qr.js"));
      } else {
         importScripts(/*BTDS*/"https:\/\/static.cdninstagram.com\/rsrc.php\/v4\/yC\/r\/378h91_48Qr.js");
      }
      